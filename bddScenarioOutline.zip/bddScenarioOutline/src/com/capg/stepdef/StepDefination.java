package com.capg.stepdef;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	WebDriver driver;
	@Given("^Navigate to Icompass URL to display login page$")
	public void navigate_to_Icompass_URL_to_display_login_page() throws Throwable {
		driver = WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);
	}

	/*@When("^User enter login credentials username \"([^\"]*)\"and password \"([^\"]*)\"$")
	public void user_enter_login_credentials_username_and_password(String ur, String pwd) throws Throwable {
	    WebElement ele = driver.findElement(By.id("userName"));
	    WebElement ele2 = driver.findElement(By.id("password"));
	    ele.sendKeys(ur);
	    ele2.sendKeys(pwd);
	}
*/
	
	@When("^User enter login credentials$")
	public void user_enter_login_credentials(DataTable data) throws Throwable {
		
		List<List<String>> table =data.raw();
		WebElement ele = driver.findElement(By.id("userName"));
	    WebElement ele2 = driver.findElement(By.id("password"));
	    
	    String un = table.get(0).get(0);
	   String pw = table.get(0).get(1);
	   
	   ele.sendKeys(un);
	   ele2.sendKeys(pw);
	    
	    
	}
	
	
	@Then("^validations should be performed$")
	public void validations_should_be_performed() throws Throwable {
	    WebElement login = driver.findElement(By.id("loginButton"));
	    login.click();
	}

  
}
