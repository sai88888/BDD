package com.cap.xyzbank.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cap.xyzbank.entities.BankEntity;
import com.cap.xyzbank.entities.TransEntity;

public class BankDao implements BankDaoI {

	long bacc;
	int balance11, data1, data2, data3, data4;
	ArrayList<TransEntity> te;

	EntityManager entitymanager;

	public BankDao() {
		entitymanager = JPAUtil.getEntityManager();
	}

	public void gettransactionbegin() {
		entitymanager.getTransaction().begin();
	}

	public void gettransactioncommit() {
		entitymanager.getTransaction().commit();
	}

	public long createAccount1(BankEntity bean) {
		bacc = bean.getBacc();
		entitymanager.persist(bean);

		return bacc;
	}

	public int showbalace1(long account1, String password1) {

		BankEntity be = entitymanager.find(BankEntity.class, new Long(account1));
		if (be == null) {
			throw new AccountNotFoundException("enter valid account number ");
		} else if (password1.equals(be.getBpass())) {
			balance11 = be.getBbal();
			return balance11;
		} else {
			throw new PasswordNotFoundException("password is not correct");
		}

	}

	public int deposit1(long account2, String password2, int dep1) {
		if(dep1>0)
		{
		BankEntity be21 = entitymanager.find(BankEntity.class, account2);
		if (be21 == null) {
			throw new AccountNotFoundException("enter valid account number ");
		} else if (password2.equals(be21.getBpass())) {
			balance11 = dep1 + be21.getBbal();
			be21.setBbal(balance11);
			entitymanager.merge(be21);

			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			TransEntity tb = new TransEntity();
			tb.setBaccInitial(account2);
			tb.setTransdate(formatter.format(date));
			tb.setTransBal(dep1);
			tb.setTransMetd("deposit");
			tb.setBank(be21);
			tb.setBaccFinal(balance11);
			entitymanager.persist(tb);

		} else {
			
			throw new PasswordNotFoundException("enter valid details");
		}}else {
			throw new PasswordNotFoundException("enter valid deposit amount");
		}
		return balance11;
	}

	public int withdrawl1(long account3, String password3, int dep3) {
if(dep3>0) {
		BankEntity be21 = entitymanager.find(BankEntity.class, account3);
		if (be21 == null) {
			throw new AccountNotFoundException("enter valid account number ");
		} else if (password3.equals(be21.getBpass())) {
			balance11 = be21.getBbal() - dep3;
			if(balance11>1000) {
			be21.setBbal(balance11);
			entitymanager.merge(be21);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			TransEntity tb = new TransEntity();
			tb.setBaccInitial(account3);
			tb.setTransdate(formatter.format(date));
			tb.setTransBal(dep3);
			tb.setTransMetd("withdrawl");
			tb.setBank(be21);
			tb.setBaccFinal(balance11);
			entitymanager.persist(tb);
			}
			else {
				throw new PasswordNotFoundException("enter correct amount");
			}
		} else {
			throw new PasswordNotFoundException("password is not correct");
		}}else {
			throw new PasswordNotFoundException("enter valid amount");
		}
		return balance11;
	}

	public int fund1(long account31, long account32, String password31, int k1) {
if(k1>0) {
		BankEntity be31 = entitymanager.find(BankEntity.class, new Long(account31));
		if (be31 == null) {
			throw new AccountNotFoundException("enter valid account number ");
		} else if (password31.equals(be31.getBpass())) {
			balance11 = be31.getBbal() - k1;
			if(balance11>1000) {
			be31.setBbal(balance11);
			entitymanager.merge(be31);

			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			TransEntity tb = new TransEntity();
			tb.setBank(be31);
			tb.setBaccInitial(account31);
			tb.setTransdate(formatter.format(date));
			tb.setTransBal(balance11);
			tb.setTransMetd("fundsGiven");

			tb.setBaccFinal(balance11);
			entitymanager.persist(tb);}
			else {
//				throw new PasswordNotFoundException("enter balance which is less than account balance");
				return -1;
			}
		} else {
			throw new PasswordNotFoundException("password is not correct");
		}

		BankEntity be1 = entitymanager.find(BankEntity.class, new Long(account32));
		if (be1 == null) {
			throw new AccountNotFoundException("enter valid account number ");
		} else {
			int balance12 = be1.getBbal() + k1;
			be1.setBbal(balance12);
			entitymanager.merge(be1);

			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			TransEntity tb = new TransEntity();
			tb.setBaccInitial(account32);
			tb.setTransdate(formatter.format(date));
			tb.setTransBal(balance12);
			tb.setTransMetd("fundsTaken");
			tb.setBank(be1);
			tb.setBaccFinal(balance12);
			entitymanager.persist(tb);
		}}else {
			throw new PasswordNotFoundException("enter valid amount");
		}
		return balance11;
	}

	public List transaction(long account12) {
		BankEntity bank = entitymanager.find(BankEntity.class, new Long(account12));
		if (bank == null) {
			throw new AccountNotFoundException("enter valid account number ");
		} else {
			TypedQuery<TransEntity> trans = entitymanager
					.createQuery("SELECT  t from TransEntity as t where t.bank=:bank", TransEntity.class);
			trans.setParameter("bank", bank);
			te = (ArrayList<TransEntity>) trans.getResultList();
			return te;
		}
	}

	public boolean validation(long account1, String password1) {

		BankEntity be1 = entitymanager.find(BankEntity.class, account1);
		if (be1 == null) {
			return false;
		} else if (be1.getBpass().equals(password1)) {
			return true;
		} else {
			return false;
		}

	}

}
