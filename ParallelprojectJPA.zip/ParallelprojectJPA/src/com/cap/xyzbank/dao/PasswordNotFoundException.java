package com.cap.xyzbank.dao;

public class PasswordNotFoundException extends RuntimeException {
	BankDao dao=new BankDao();
	
	public PasswordNotFoundException(String s) {
		super(s);
		dao.gettransactioncommit();
	}
}
