package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class SwitchingWindows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = WebUtil.getWebDriver();
		driver.get("C:\\Users\\saikota\\bddWorkSpace\\SeleniumWebDriver\\html\\PopupWin.html");
		
		String parent_window =driver.getWindowHandle();
		
		driver.findElement(By.name("Open")).click();
		
		driver.switchTo().window("PopupWindow");
		
		//driver.close();
		driver.findElement(By.name("txtName")).sendKeys("sai");
		driver.findElement(By.name("btnAlert")).click();
		driver.switchTo().alert().accept();
		driver.close();
		
		driver.switchTo().window(parent_window);
		
		driver.close();
	}

}
