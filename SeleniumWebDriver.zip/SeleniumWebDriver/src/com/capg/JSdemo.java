package com.capg;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;



public class JSdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver= WebUtil.getWebDriver();
		
		//driver.get("C:\\Users\\saikota\\bddWorkSpace\\SeleniumWebDriver\\html\\demo.html");
		
		
		driver.get("https://en.wikipedia.org/wiki/India");
		
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		jse.executeScript("window.scrollBy(0,1000)");
		
		//jse.executeScript("display()");
		
		//String str = jse.executeScript("return document.getElementById('h1').innerHTML").toString();
		
	//	System.out.println(str);
		
		//driver.quit();
		
	}

}
