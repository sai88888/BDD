package com.capg;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebElementsDemo {

	
	public static void main(String args[]) {
		
		WebDriver driver =WebUtil.getWebDriver();
	driver.navigate().to("https://www.toolsqa.com/automation-practice-form");
	
	        //https://www.toolsqa.com/automation-practice-form
		
			/*WebElement link1 =driver.findElement(By.partialLinkText("SELENIUM"));
			link1.click();
			
			driver.navigate().back();*/
			
			//WebElement link2 =driver.findElement(By.linkText("ABOUT"));
			//link2.click();
			
			//driver.quit();
			//WebElement radioButton =driver.findElement(By.id("sex-0"));
			//radioButton.click();
			
			//WebElement checkList =driver.findElement(By.id("continents"));
			
			//checkList.click();
			
			/*WebElement element=driver.findElement(By.id("continents"));
			Select se=new Select(element);
			se.selectByIndex(2);
			*/
			/*WebElement element2=driver.findElement(By.id("continentsmultiple"));
			Select se2=new Select(element2);
			se2.selectByIndex(2);*/
			
			
			//MethodName: selectByValue
			/*WebElement element=driver.findElement(By.name("Mobiles"));
			Select se=new Select(element);
			se.selectByValue("Africa");*/
			
			//MethodName: selectByVisibleText
			/*WebElement element=driver.findElement(By.name("Mobiles"));
			Select se=new Select(element);
			se.selectByVisibleText("Africa");*/
	
	//driver.findElement(By.xpath("//form")).sendKeys(Keys.PAGE_DOWN);
			
			//WebElement element3=driver.findElement(By.xpath("//*[@id=\"continents\"]"));
			//WebElement element3=driver.findElement(By.xpath("//select[@name=\"continents\"]"));
			//Select se3=new Select(element3);
			//se3.selectByIndex(2);
			
	WebElement checkbox=driver.findElement(By.id("tool-0"));
	
			checkbox.click();
			
	}
}
