package com.capg.stepdefination;

import java.sql.DriverPropertyInfo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	WebDriver driver;
	@Given("^Navigate to Icompass URl$")
	public void navigate_to_Icompass_URl() throws Throwable {
	   
		driver =WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);
		
	}

	@When("^user Enter valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_Enter_valid_username_and_valid_password(String username, String password) throws Throwable {
	   
		WebElement  userTextField = driver.findElement(By.id("userName"));
		
		WebElement  passwordTextField = driver.findElement(By.id("password"));
		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);
	}

	@Then("^Login Successfully$")
	public void login_Successfully() throws Throwable {
	   
		
		WebElement login =driver.findElement(By.id("loginButton"));
		login.click();
		 driver.close();
	}

	@Given("^Navigate to Google URl$")
	public void navigate_to_Google_URl() throws Throwable {
		driver =WebUtil.getWebDriver();
		String url = "http:www.google.com";
		driver.navigate().to(url);   //driver.get()
		
		
		
	}

	@When("^user Enter input \"([^\"]*)\"$")
	public void user_Enter_input(String input) throws Throwable {
		
	    
		WebElement searchField = driver.findElement(By.name("q"));
		
		searchField.sendKeys(input);
		searchField.sendKeys("\n"); //+"\n"
		
	}

	@Then("^climate display detail$")
	public void climate_display_detail() throws Throwable {
	   System.out.println("climate details displayed");
	   driver.close();
	}

	@When("^user Enter input image link$")
	public void user_Enter_input_image_link() throws Throwable {
		
		
		
		WebElement imglink =driver.findElement(By.className("gb_e"));
		
		imglink.click();
	}

	@Then("^Display images page$")
	public void display_images_page() throws Throwable {
	   System.out.println("Images page displayed");
	   driver.close();
	}

}
