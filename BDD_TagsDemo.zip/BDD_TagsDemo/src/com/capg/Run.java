package com.capg;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/login.feature" ,tags = {"@SmokeTest,@Test"},plugin ="junit:jtypeexp/jtypeexp.xml")//logical OR
//@CucumberOptions(features="src/login.feature" ,tags = {"@SmokeTest","@Test"})//logical AND
public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
