package com.capg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebUtil {

	
	public static WebDriver getWebDriver() {
		String str = "C:\\Users\\saikota\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", str);
		WebDriver driver =new ChromeDriver();
		return driver;
	}
}
