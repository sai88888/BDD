$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/login.feature");
formatter.feature({
  "line": 1,
  "name": "Multiple Scenario Testing",
  "description": "",
  "id": "multiple-scenario-testing",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "Login Icompass with valid credentials",
  "description": "",
  "id": "multiple-scenario-testing;login-icompass-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@SmokeTest"
    },
    {
      "line": 4,
      "name": "@Test"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "Navigate to Icompass URl",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user Enter valid username \"190115\" and valid password \"Love*Care\"",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "Login Successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.navigate_to_Icompass_URl()"
});
formatter.result({
  "duration": 8974989600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "190115",
      "offset": 27
    },
    {
      "val": "Love*Care",
      "offset": 55
    }
  ],
  "location": "StepDef.user_Enter_valid_username_and_valid_password(String,String)"
});
formatter.result({
  "duration": 246173600,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.login_Successfully()"
});
formatter.result({
  "duration": 279338300,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Climate updates",
  "description": "",
  "id": "multiple-scenario-testing;climate-updates",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 11,
      "name": "@Test"
    }
  ]
});
formatter.step({
  "line": 13,
  "name": "Navigate to Google URl",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "user Enter input \"chennai climate\"",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "climate display detail",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.navigate_to_Google_URl()"
});
formatter.result({
  "duration": 5790326900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "chennai climate",
      "offset": 18
    }
  ],
  "location": "StepDef.user_Enter_input(String)"
});
formatter.result({
  "duration": 4646228900,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.climate_display_detail()"
});
formatter.result({
  "duration": 2332630200,
  "status": "passed"
});
});