package com.capg.defination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BddDefination {

	WebDriver driver;
	
	@Given("^Open Any Browser and Enter Flipkart URL$")
	public void open_Any_Browser_and_Enter_Flipkart_URL() throws Throwable {
	   String str = "C:\\Users\\saikota\\Drivers\\chromedriver.exe";
	   System.setProperty("webdriver.chrome.driver", str);
	   driver = new ChromeDriver();
	   driver.get("https://www.flipkart.com/?gclid=EAIaIQobChMI_6yi8KLf5AIVxIBwCh2JQwXjEAAYASAAEgJbTfD_BwE&ef_id=EAIaIQobChMI_6yi8KLf5AIVxIBwCh2JQwXjEAAYASAAEgJbTfD_BwE:G:s&s_kwcid=AL!739!3!260704327909!e!!g!!flipkart&semcmpid=sem_8024046704_brand_eta_goog");
	   
	}

	@When("^User Enters valid username \"([^\"]*)\" valid password \"([^\"]*)\"$")
	public void user_Enters_valid_username_valid_password(String username, String password) throws Throwable {
	  WebElement e1= driver.findElement(By.className("_2zrpKA")); 
	  WebElement e2= driver.findElement(By.className("_3v41xv"));
	  e1.sendKeys(username);
	  e2.sendKeys(password);
	}

	@Then("^Login in to Flipkart successfully$")
	public void login_in_to_Flipkart_successfully() throws Throwable {
	   
		WebElement login =driver.findElement(By.className("_7UHT_c"));
		login.click();
		
	}
	
	
	
}
